
#include <stdlib.h>
#include <string.h>

#include <stdlib.h>
#include <string.h>


// include NESLIB header
#include "neslib.h"

// include CC65 NES Header (PPU)
#include <nes.h>

// link the pattern table into CHR ROM
//#link "chr_generic.s"

// BCD arithmetic support
#include "bcd.h"
//#link "bcd.c"

// VRAM update buffer
#include "vrambuf.h"
//#link "vrambuf.c"

#include <stdbool.h>

/*{pal:"nes",layout:"nes"}*/
const char PALETTE[32] = { 
  0x13,			// screen color

  0x11,0x30,0x27,0x0,	// background palette 0
  0x1c,0x20,0x2c,0x0,	// background palette 1
  0x00,0x10,0x20,0x0,	// background palette 2
  0x06,0x16,0x26,0x0,   // background palette 3

  0x16,0x35,0x24,0x0,	// sprite palette 0
  0x00,0x37,0x25,0x0,	// sprite palette 1
  0x0d,0x2d,0x3a,0x0,	// sprite palette 2
  0x0d,0x27,0x2a	// sprite palette 3
};

// setup PPU and tables
void setup_graphics() {
  // clear sprites
  oam_clear();
  // set palette colors
  pal_all(PALETTE);
}

void title_screen(char pad, bool choice){
  int iter = 0;
  vram_adr(NTADR_A(9, 12));
  vram_write("PSYCHO MANTIS", 13); 
  
  vram_adr(NTADR_A(10, 20));
  vram_write("PRESS START", 11); 
  ppu_on_all();
  
  for(iter = 0; iter < 50; iter++)
  {
    ppu_wait_frame();
  }
  
  while (choice == false)
  {
    pad = pad_poll(0);
    if(pad&PAD_START)
    {
      choice = true;
      ppu_off();
    }
  }
}

void main(void)
{
  bool flag = false;
  bool choice = false;
  int iter;
  int max = 100;
  int low = 0;
  int guess = 0;
  char guec[3];
  int i = 0;
  char pad;	
  setup_graphics();
  
  //TITLE SCREEN//
  title_screen(pad, choice);
  ppu_off();
  
  //CLEARING MEMORY//////////////////////////
  vram_adr(NTADR_A(9, 12));
  vram_write("                           ", 13); // clear this rows text
  
  vram_adr(NTADR_A(10, 20));
  vram_write("                           ", 11);
  
  // draw message  
  // MESSAGE 1 ////////////////////////////////
  vram_adr(NTADR_A(13, 12));
  vram_write("HELLO.", 6);
  
  vram_adr(NTADR_A(4, 14));
  vram_write("LET ME GUESS YOUR NUMBER.", 25);
  
  
  
  // enable rendering
  ppu_on_all();
  
  
  for(iter = 0; iter < 130; iter++)
  {
    ppu_wait_frame();
  }
  // TURN OFF THE STUPID SCREEN
  ppu_off();
  
  
  
  /////////////////////////////////////////////
  vram_adr(NTADR_A(8, 12));
  vram_write("THINK OF A NUMBER", 17);
  
  vram_adr(NTADR_A(2, 14));
  vram_write("BETWEEN ZERO AND ONE HUNDRED", 28);
  // enable rendering
  ppu_on_all();
  
  for(iter = 0; iter < 200; iter++)
  {
    ppu_wait_frame();
  }
  ppu_off();
  
  guess = (max + low) / 2; // should initialize to 50 here
  
  
  
  /////////////////////////////////////////////
  // LOOPING PART OF THE GUESSING GAME.
  while(!flag)
  {
    choice = false;
    vram_adr(NTADR_A(2, 14));
    vram_write("                           ", 28); // clear this rows text
    
    itoa(guess, guec, 10); // convert int to chr*
 
    
    vram_adr(NTADR_A(5, 12));
    vram_write("I GUESS YOUR NUMBER IS: ", 24);
    
    vram_adr(NTADR_A(15, 14));
    vram_write(guec, 2);
    // String interpolation here
    
    vram_adr(NTADR_A(2, 18));
    vram_write("A:Too High", 11);
    
    vram_adr(NTADR_A(2, 20));
    vram_write("B:Too Low", 10);
    
    vram_adr(NTADR_A(2, 22));
    vram_write("Start:Correct", 14);
    
    
    
    // enable rendering
    ppu_on_all();
    
    for(iter = 0; iter < 50; iter++)
    {
      ppu_wait_frame();
    }
    
    while(choice == false)
    {
      //for(i = 0; i<2; i++)
      //{
        pad = pad_poll(0);
        if(pad&PAD_A){
          max = guess - 1;
          guess = (max + low) / 2;
          choice = true;
          ppu_off();
        }
        else if(pad&PAD_B){
          low = guess + 1;
          guess = (max + low) / 2;
          choice = true;
          ppu_off();
        }

        else if(pad&PAD_START){
          flag = true;
          choice = true;
          ppu_off();
      	}
      //}
    }
  }
  // infinite loop
  while(1) {
    ppu_off();
    vram_adr(NTADR_A(13, 12));
    vram_write("help i'm stuck", 22);
    
    vram_adr(NTADR_A(13, 20));
    vram_write("is that you, god?", 30);
    ppu_on_all();
  }
}

